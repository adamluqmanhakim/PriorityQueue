package assignment3;

public class Jobs
{
	private String jobName;					// indicates the name of a process/job
	private int jobLength;					// indicates the needed CPU cycles for this job to terminate
	private int currentJobLength;           // indicates the remaining length of the job at any give time
	private int jobPriority;				// indicates the initial priority of the job
	private int finalPriority;				// indicates the final priority of the job at termination time
	private long entryTime;					// indicates the time this job entered the priority queue
	private long endTime;					// indicates when this job finally terminated
	private long waitTime ;					// indicates the total amount of wait time a process had to sustain from the time it entered the queue until it terminates
	private static  int currentTime = 0;
	private static int finished  = 0;
	private int key;
	private Jobs jobs;
	
	public Jobs (String jobName , int jobLength , int jobPriority , long entryTime ){
		this.jobName=jobName;
		this.jobLength= jobLength;
		this.currentJobLength= jobLength;
		this.jobPriority = jobPriority;
		this.finalPriority = jobPriority;
		this.entryTime= entryTime;
	}

	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

	public int getJobLength() {
		return jobLength;
	}

	public void setJobLength(int jobLength) {
		this.jobLength = jobLength;
	}

	public int getCurrentJobLength() {
		return currentJobLength;
	}

	public void setCurrentJobLength(int currentJobLength) {
		this.currentJobLength = currentJobLength;
	}

	public int getJobPriority() {
		return jobPriority;
	}

	public void setJobPriority(int jobPriority) {
		this.jobPriority = jobPriority;
	}

	public int getFinalPriority() {
		return finalPriority;
	}

	public void setFinalPriority(int finalPriority) {
		this.finalPriority = finalPriority;
	}

	public long getEndTime() {
		return endTime;
	}

	public void setEndTime(long endTime) {
		this.endTime = endTime;
	}

	public long getWaitTime() {
		return waitTime;
	}

	public void setWaitTime(long waitTime) {
		this.waitTime = waitTime;
	}
	
	public static int getCurrentTime(){
		return currentTime ;
	}
	
	public static void setCurrentTime(int currentTime ){
		Jobs.currentTime=currentTime ;	
	}
	
	public static int getFinished(){
		return finished ;
	}
	
	public static void setFinished (int finished ){
		Jobs.finished = finished ;
	}
	
	public static void execute(Jobs job){
		job.currentJobLength=job.currentJobLength-1;
		if(job.currentJobLength == 0) {
			finished++;
		}			
		currentTime++;	
	}
	
	public long getEntryTime() {
		return entryTime;
	}

	public void setEntryTime(long entryTime) {
		this.entryTime = entryTime;
	}
	
	//it will hold the priority queue of the Jobs and job class
	public Jobs(int key , Jobs jobs){
		this.setKey(key);
		this.setJobs(jobs);
	}
	
	public Jobs getJobs(){
		return jobs;
	}

	public void setJobs( Jobs jobs){
		this.jobs = jobs;
	}
	public int getKey(){
		return key;
	}
	public void setKey(int key){
		this.key=key;
	}

	public String toString(){
		return "Now executing : "+jobName+", Job length: "+jobLength+" cycles; current remaining length: "+currentJobLength+" cycles;"+" Initial priority: "+ jobPriority+";current priority : "+finalPriority;
	}	
}