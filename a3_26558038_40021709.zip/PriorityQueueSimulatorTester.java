 package assignment3;

 import java.io.BufferedWriter;
 import java.io.FileWriter;
 import java.io.IOException;
 
public class PriorityQueueSimulatorTester
{
	public static void main(String[] args) throws IOException
	{
		// ----------------- UNSORTED LIST ---------------------
		Job[] jobsInputArray = null; 							// Generate array of jobs
		int currentNumberOfJobs = 0; 							// Stores number of jobs to create for the current cycle
		
		for(int j = 0; j < maxNumberOfJobs.length; j++)
		{
			// ---- VARIABLES TO RESET EVERY CYCLE OF JOBS -----
			avgWaitTime = 0;
			currentTime = 0;
			doneJobs = 0;
			priorityChanges = 0;
			waitingTimeSum = 0;
			processes = 0;
			terminator = 0;
			
			// ---------------- CREATE JOBS --------------------
			currentNumberOfJobs = maxNumberOfJobs[j];  			// store current amount of jobs for this iteration
			jobsInputArray = new Job[currentNumberOfJobs]; 		// creates an array of length currentAmountOfJobs
			int randomCycles = 0;								// random # of cycles to assign every job
			int randomPriority = 0;								// random priority to assign every job
			for(int i = 0; i < currentNumberOfJobs; i++)   		// declare indicated amount of jobs for this iteration
			{
				randomCycles = (int)((Math.random()*70)+1);
				randomPriority = (int)((Math.random()*40)+1);
				jobsInputArray[i] = new Job(i, randomCycles, randomPriority, i);
			}
			
			// ---------------- CREATE PQ -----------------------
			UnsortedList pq = new UnsortedList(currentNumberOfJobs);
			
			// --------- INSERT JOBS FROM ARRAY TO PQ -----------
			for(int i = 0; i < jobsInputArray.length; i++)
			{
				pq.insert(jobsInputArray[i].getJobPriority(), jobsInputArray[i]);
				currentTime++;
			}
						
			// ----------- START NANOSECONDS TIMER --------------
			long startTime = System.nanoTime();
			
			// ------------- START CPU PROCESSING ---------------			
			while(!pq.isEmpty()) 								// Execute as long as the priority queue has any jobs inside		
			{
				if(terminator == 30)							// If the program has terminated 30 jobs, then execute starvation process
				{
					pq.starvation();							// Execute starvation process
					currentTime++;								// Increment by 1 time unit
					priorityChanges++;							// Increment # of priority changes by 1
					terminator = 0;								// Restart terminated jobs
				}
				
				Job jobHolder = (Job)pq.removeMin();			// To hold the job under processing (casting is just in case the removal acts up like before)
				
				if(jobHolder == null)							// IF jobHolder turns out to be a null reference, execute removeMin again by going through the loop once again
					continue;
				
				int reducedCycle = jobHolder.getCurrentJobLength() - 1;	// Decrement and store number of cycles for current job
								
				jobHolder.setCurrentJobLength(reducedCycle); 	// Decrement amount of cycles for the processed job
				
				System.out.println(jobHolder);				// Print current job info
				
				if(jobHolder.getCurrentJobLength() > 0)			// If the current processed job has any remaining cycles the program will insert it back into the PQ
					pq.insert(jobHolder.getFinalPriority(), jobHolder);
				
				if(jobHolder.getCurrentJobLength() == 0)		// If the current processed job has no more remaining cycles the program will collect its data
				{
					jobHolder.setEndTime(currentTime);			// Record endTime for this job
					jobHolder.setWaitTime((jobHolder.getEndTime() - jobHolder.getEntryTime()) - jobHolder.getJobLength()); // Calculate waitTime for this job
					doneJobs++;									// Increment amount of jobs terminated
					terminator++;								// Increment terminator to use for starvation
					waitingTimeSum += jobHolder.getWaitTime();	// Add up every waiting time for every terminated job
				}
				
				currentTime++;									// Increment CPU timer by 1 unit of time every time a job is processed
				processes++;									// Increment number of jobs processed
			}
			
			// ----------- END NANOSECONDS TIMER --------------
			long endTime = System.nanoTime();
			long totalTime = (endTime - startTime);
			avgWaitTime = waitingTimeSum/doneJobs;
			
			// ---------------- PRINT REPORT ------------------
			System.out.println("---------- REPORT: Unsorted List ----------");
			System.out.println("Current system time (cycles): " + processes);
			System.out.println("Total number of jobs executed: " + maxNumberOfJobs[j] + " jobs");
			System.out.println("Average process waiting time: " + avgWaitTime + " cycles" );
			System.out.println("Total number of priority changes: " + priorityChanges );
			System.out.println("Actual system time needed to execute all jobs: " + totalTime + " ns\n");
			
			// --------- OUTPUT REPORT TO TEXT FILE -----------
			BufferedWriter writer = new BufferedWriter(new FileWriter("SimulatorPerformanceResults.txt", true));
			
			writer.write("---------- REPORT: Unsorted List ----------");
			writer.write("\r\n");
			writer.write("Current system time (cycles): " + processes);
			writer.write("\r\n");
			writer.write("Total number of jobs executed: " + maxNumberOfJobs[j] + " jobs");
			writer.write("\r\n");
			writer.write("Average process waiting time: " + avgWaitTime + " cycles" );
			writer.write("\r\n");
			writer.write("Total number of priority changes: " + priorityChanges );
			writer.write("\r\n");
			writer.write("Actual system time needed to execute all jobs: " + totalTime + " ns");
			writer.write("\r\n");
			writer.write("\r\n");
			
			writer.close();
		}
		
		/* DEAD CODE DEAD CODE DEAD CODE DEAD CODE DEAD CODE DEAD CODE
		// ----------------- Unsorted List ---------------------		
		for(int j = 0; j < maxNumberOfJobs.length; j++)
		{
			// ---- VARIABLES TO RESET EVERY CYCLE OF JOBS -----
			avgWaitTime2 = 0;
			currentTime2 = 0;
			doneJobs2 = 0;
			priorityChanges2 = 0;
			waitingTimeSum2 = 0;
			processes = 0;
			terminator = 0;
			
			// ---------------- CREATE JOBS --------------------
			currentNumberOfJobs = maxNumberOfJobs[j];  			// store current amount of jobs for this iteration
			jobsInputArray = new Job[currentNumberOfJobs]; 		// creates an array of length currentAmountOfJobs
			int randomCycles = 0;								// random # of cycles to assign every job
			int randomPriority = 0;								// random priority to assign every job
			for(int i = 0; i < currentNumberOfJobs; i++)   		// declare indicated amount of jobs for this iteration
			{
				randomCycles = (int)((Math.random()*70)+1);
				randomPriority = (int)((Math.random()*40)+1);
				jobsInputArray[i] = new Job(i, randomCycles, randomPriority, i);
			}
			
			// ---------------- CREATE PQ -----------------------
			Array pq = new UnsortedList(currentNumberOfJobs);
			
			
		}*/
	}
	
	public static int[] maxNumberOfJobs = {100, 1000, 10000}; // sizes of jobsInputArray
		
	public static int processes = 0; 	// amount of CPU cycles
	
	public static int terminator = 0; 	// amount of terminated jobs (this amount restarts after 30 jobs)
	/*
	 * currentTime increments by 1 unit of time when:
	 * 		- A new job is inserted into the PQ
	 * 		- A job is executed
	 * 		- starvation() is executed
	 */
	public static int currentTime = 0, currentTime2 = 0; 			// amount of time units passed

	public static int priorityChanges = 0, priorityChanges2 = 0;	// priority changes made
	
	public static double avgWaitTime = 0, avgWaitTime2 = 0;			// idle time in average
	
	public static long waitingTimeSum = 0, waitingTimeSum2 = 0;		// sum of waiting times
	
	public static int doneJobs = 0, doneJobs2 = 0;					// amount of jobs processed (unlike terminator, this counter does not restart after 30 jobs)
}