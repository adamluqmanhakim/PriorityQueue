package assignment3;

import java.util.ArrayList;

public class PriorityJobsHeap {
	//arrayList  of  task (key,value )
	private ArrayList array;
	private int size =0;


	//initialize size of the array
	public PriorityJobsHeap(int size) {
		array= new ArrayList(size);
	}

	public ArrayList getValues(){
		return array;
	}

	public void setValues (ArrayList array){
		this.array =array;
	}

	//initialize of the array
	public  Jobs insert (int key,Jobs jobs){
		//check if the are available spots in the priority q
		if(size == array.size()+1)throw new IndexOutOfBoundsException();

		Jobs task= new Jobs(key,jobs);
		array.add(task);
		size++;

		//if size bigger bigger than 1
		if (size > 1){
			upHeap(task);
		}
		return task;
	}

	private void upHeap(Jobs jobs){
		//stopping case : if the node is in the root 
		//if the index its null 
		if (array.indexOf(jobs) == 0)
			return;
		//if its not initialize to childIndex 
		int childIndex = array.indexOf(jobs);
		//get the parent index based on the child

		int parentIndex = childIndex % 2 == 0 ? (childIndex-2)/2 : (childIndex-1)/2;

		Jobs parentP = (Jobs) array.get(parentIndex);
		Jobs childP = (Jobs) array.get(childIndex);
		//if the parent key is bigger than the child key 
		if (parentP.getKey() > childP.getKey()){
			Jobs temp = parentP;
			array.set(parentIndex, childP );
			array.set(childIndex, temp );
			upHeap(childP);

		}
		//if not, do not upheap
		return;

	}

	public Jobs removeMin(){
		//if the priority q is empty
		if (isEmpty()) throw new IndexOutOfBoundsException();
		//if size is equal than 1 
		if (size == 1 ){
			size --;
			return (Jobs) array.remove(0);

		}
		Jobs temp = (Jobs) array.get(0);
		array.set(0, array.remove(array.size()-1));
		size--;

		//if size is bigger than  1 and 
		if (size > 1 ){
			downHeap((Jobs)array.get(0));

		}
		return temp;


	}
	
	public Jobs min(){
		if (!isEmpty()){
			return (Jobs)array.get(0);

		}
		return null;

	}

	private void downHeap (Jobs jobs ){
		int left = 2*array.indexOf(jobs)+1 ;
		int right = 2*array.indexOf(jobs)+2;
		if (left >= array.size() & right >= array.size()){
			return;
		}
		int change ;
		if (left >= array.size()){
			change= right ;

		}
		else if (right >= array.size()){
			change =left;

		}
		else{
			change =((Jobs) array.get(left)).getKey() <= ((Jobs) array.get(right)).getKey() ? left : right;

		}
		array.set(array.indexOf(jobs),array.get(change));
		array.set(change , jobs );
		downHeap(jobs);

	}
	public boolean isEmpty(){
		return size == 0;

	}

	public Jobs findOldest(){
		Jobs temp = (Jobs )array.get(0);
		long oldest = 0;
		for (int i =0; i<array.size();i++){
			Jobs job = ((Jobs) array.get(i)).getJobs();
			if(job.getEntryTime() > oldest && job.getJobLength()== job.getCurrentJobLength()){
				oldest = job.getEntryTime();
				temp =(Jobs) array.get(i);

			}
		}
		temp.setKey(0);
		upHeap(temp);
		return temp;

	}
}