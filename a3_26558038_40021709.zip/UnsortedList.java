package assignment3;

public class UnsortedList
{
	private Job[] data;	// the priority queue holding the jobs
	
	public UnsortedList(int capacity)
	{
		data = new Job[capacity];
	}
	
	// To check if the array is empty
	public boolean isEmpty()
	{
		return getArraySize() == 0;
	}
	
	// Inserts an element at the first null reference it finds in the array
	public void insert(int prio, Job job)
	{
		job.setFinalPriority(prio);			// the priority for this job
		
		if(getArraySize() != data.length)	// insert element if amount of elements is not the same length of our data array
		{
			data[getArraySize()] = job;
		}
	}
	
	public String values()
	{
		int size = 0;
		for(int i = 0; i < data.length; i++)
		{
			if(data[i] == null)
				continue;
			else
			{
				System.out.println("Value " + data[i].getName() + " with priority " + data[i].getFinalPriority() + " is in index: " + i);
				size++;
			}
		}
		
		System.out.println("FOR A TOTAL OF " + size + " VALUES LEFT");
		
		return "\nREAD UP";
	}
	
	// To check the size
	public int getArraySize()
	{
		int size = 0;
		for(int i = 0; i < data.length; i++)
		{
			if(data[i] == null)
				continue;
			else
				size++;
		}
		return size;
	}

	// Executes starvation process: find lowest priority index, changes its priority to 1, push to the front of the array
	public void starvation()
	{
		long entryTime = data[0].getEntryTime();			// to store entry time
		int index = 0;										// to store index of the job
		
		if(getArraySize() == 0)								// to explain WHY this method might not work (when the array is empty)
			System.out.println("The PQ is empty");
		else
		{
			for(int i = 0; i < data.length; i++)				// go through all array elements
			{
				if(data[i] == null)								// we're not concerned with null places in the array, so continue
					continue;
				else if(data[i].getEntryTime() > entryTime)		// check if the current job's entry time is bigger than the one stored in entryTime
				{
					entryTime = data[i].getEntryTime();			// found a higher entry time, so save the new job's entry time
					index = i;									// and save the new job's index as well
				}
			}
		}
		
		// once the loop is done we can change the job's priority to 1
		data[index].setFinalPriority(1);
	}

	// Removes and returns the job with the highest priority
	public Job removeMin()
	{
		int priority = 40, index = 0;
		Job jobHolder = null;
		
		if(getArraySize() == 0)
		{
			System.out.println("Array is empty.");
			return null;
		}
		
		// yes, so far this is the same method as topPriority, but with a plot twist, keep reading
		for(int i = 0; i < data.length; i++) 
		{
			if(data[i] == null)
				continue;
			else if(data[i].getFinalPriority() < priority)
			{
				priority = data[i].getFinalPriority();
				jobHolder = data[i];
				index = i;
			}
		}
		
		//System.out.println("Job with smallest current priority is " + jobHolder.getJobName() + " with priority " + jobHolder.getFinalPriority());
		
		// change the found job to null
		data[index] = null;
		
		// shift all values from right to left
		for(int i = index; i < data.length-1; i++)
			data[i] = data[i + 1];
		
		// last space in the array has been freed up, now it's null
		data[data.length-1] = null;
		
		return jobHolder;
	}
	
	// Returns the job with the highest priority
	public Object topPriority()
	{
		Job jobHolder = null;
		int priority = 0;
		if(getArraySize() == 0)
		{
			return null;
		}

		for(int i = 0; i < data.length; i++)
		{
			if(data[i] == null)
				continue;
			else if(data[i].getFinalPriority() < priority)
			{
				priority = data[i].getFinalPriority();
				jobHolder = data[i];
			}
		}
		return "(" + priority + ", " + jobHolder + ")";
	}
	
}