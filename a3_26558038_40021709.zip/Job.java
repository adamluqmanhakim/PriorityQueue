package assignment3;

public class Job
{
	private String jobName; 		// indicates the name of a process/job
	private int jobLength; 			// indicates the needed CPU cycles for this job to terminate
	private int currentJobLength; 	// indicates the remaining length of the job at any give time
	private int jobPriority; 		// indicates the initial priority of the job
	private int finalPriority; 		// indicates the final priority of the job at termination time
	private long entryTime; 		// indicates the time this job entered the priority queue
	private long endTime; 			// indicates when this job finally terminated
	private long waitTime; 			// indicates the total amount of wait time a process had to sustain from the time it entered the queue until it terminates

	public Job(){}
	
	public Job(int index, int jobLength, int jobPriority, int time)
	{
		jobName = "Job_" + (index+1);
		this.jobLength = jobLength;
		currentJobLength = jobLength;
		this.jobPriority = jobPriority;
		finalPriority = jobPriority;
		this.entryTime = time+1;
		endTime = 0;
		waitTime = 0;
	}
	
	// returns initial job priority
	public int getJobPriority()
	{
		return jobPriority;
	}
	
	public long getEntryTime()
	{
		return entryTime;
	}

	public void setEntryTime(long entryTime)
	{
		this.entryTime = entryTime;
	}

	public long getEndTime()
	{
		return endTime;
	}

	public void setEndTime(long endTime)
	{
		this.endTime = endTime;
	}

	public long getWaitTime()
	{
		return waitTime;
	}

	public void setWaitTime(long waitTime)
	{
		this.waitTime = waitTime;
	}

	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName)
	{
		this.jobName = jobName;
	}

	public void setJobLength(int jobLength)
	{
		this.jobLength = jobLength;
	}

	public void setJobPriority(int jobPriority)
	{
		this.jobPriority = jobPriority;
	}

	// returns the current priority of a job
	public int getFinalPriority()
	{
		return finalPriority;
	}
	
	// change priority to a passed priority (regularly, changes to priority 1 when terminated counter is 0)
	public void setFinalPriority(int newPriority)
	{
		finalPriority = newPriority;
	}
	
	// returns the name of the passed job
	public String getName()
	{
		return jobName;
	}
	
	// returns the job length
	public int getJobLength()
	{
		return jobLength;
	}
	
	// returns the current job length
	public int getCurrentJobLength()
	{
		return currentJobLength;
	}
	
	// sets the current job length to a value passed
	public void setCurrentJobLength(int value)
	{
		currentJobLength = value;
	}
	
	// sets the end time to a time passed
	public void setEndTime(int time)
	{
		endTime = time;
	}
	
	// sets the wait time to a time passed
	public void setWaitTime(int time)
	{
		waitTime = time;
	}	
	
	// toString for current job
	public String toString ()
	{
		return "Now executing " + getName() +". Job length: " + getJobLength() + " cycles; Current remaining length: " + getCurrentJobLength() + " cycles; Initial priority: " + getJobPriority() + "; Current Priority : " + getFinalPriority() + "\n";
	}
}