package assignment3;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.Random;
public class PriorityQueueSimulatorHeap
{
	public static void main(String[] args)
	{
		PrintWriter pw = null;
		int maxNumberOfJobs = 100;
		Random ran = new Random();
		Jobs jobsInput[]=new Jobs[maxNumberOfJobs];
		PriorityJobsHeap pq = new PriorityJobsHeap(maxNumberOfJobs);
		long waitTime=0;
		long priority=0;
		float start;


		//fill the array of jobs 
		for (int i =0;i<maxNumberOfJobs ;i++){
			String name ="Job_"+(i+1);
			int len =ran.nextInt(70)+1;
			int prio= ran.nextInt(40)+1;
			jobsInput[i]= new Jobs(name, len , prio, i+1);
		}

		start = System.nanoTime();
		//dump the elements to a priority q  
		for (int i = 0 ; i<maxNumberOfJobs;i++){
			//jobsInput[i].getJobPriority()  ---> key
			//jobsInput[i]----------------------> The jobs
			pq.insert(jobsInput[i].getJobPriority(),jobsInput[i]);
			Jobs.setCurrentTime(i+1);
		}

		//while there are jobs in the priority queue 
		while (!pq.isEmpty()){
			//check if the amount of process if less than 30 (To prevent starving)
			if (Jobs.getFinished()<30){
				Jobs job = pq.min().getJobs();
				
				//execute the job
				Jobs.execute(job);
				Jobs execute = pq.removeMin();
				System.out.println(execute.getJobs());
				//if the job has not finished , insert it again in the priority queue 
				if (job.getCurrentJobLength() > 0){
					pq.insert(job.getJobPriority(), job);
					//job.setFinalPriority(job.getJobPriority());
					job.setCurrentTime(Jobs.getCurrentTime()+1);

				}
				else {
					job.setEndTime(Jobs.getCurrentTime());
					job.setWaitTime(Jobs.getCurrentTime()-job.getJobLength()-job.getEntryTime());
					waitTime += job.getWaitTime();

				}
			}
			else{
				priority++;
				Jobs.setCurrentTime(Jobs.getCurrentTime()+1);
				Jobs oldest = pq.findOldest().getJobs();

				//execute the entirety of the oldest job 
				while (oldest.getCurrentJobLength() > 0){
					Jobs.setCurrentTime(Jobs.getCurrentTime()+1);
					oldest.setFinalPriority(1);
					oldest.setCurrentJobLength(oldest.getCurrentJobLength()-1);
					System.out.println(oldest);

				}
				oldest.setEndTime(Jobs.getCurrentTime());
				oldest.setWaitTime(Jobs.getCurrentTime()-oldest.getJobLength()-oldest.getEntryTime());
				waitTime +=oldest.getWaitTime();
				pq.removeMin();
				Jobs.setFinished(0);
			}
		}
		try{
			pw =new PrintWriter(new FileOutputStream("testrunheap.txt",true ));
			pw.println("");
			pw.println("current sysytem time (cycles): "+Jobs.getCurrentTime());
			pw.println("Total of jobs executed : "+maxNumberOfJobs);
			pw.println("Average process waiting time : "+ (waitTime/maxNumberOfJobs)+" cycles ");
			pw.println("Total number of priority  changes : "+priority);
			pw.println("Actual system time needed to execute all jobs : "+(System.nanoTime()-start)+" ns");
		}
		catch(FileNotFoundException e ){
			e.getStackTrace();
		}
		finally{
			pw.close();
		}		
	}	
}